#!/usr/bin/env python

import rospy
from takeoff import TakeoffControl  # Kalkış kontrol sınıfı
from line_follower import LineFollower  # Çizgi takip sınıfı
from open_cams import CameraHandler  # Kamera modülü
import cv2
import numpy as np

class DroneControl:
    def __init__(self):
        # Kalkış ve çizgi takip sınıfları
        self.takeoff_control = TakeoffControl()
        self.line_follower = LineFollower()

        # Kamera kontrolü için iki farklı handler
        self.front_camera = CameraHandler('/front_cam/camera/image', "Front Camera")
        self.downward_camera = CameraHandler('/downward_cam/downward_camera/image', "Downward Camera")

    def start_mission(self):
        """
        Görevi başlatır: Önce kalkış yapar, ardından çizgi takibe başlar.
        """
        rospy.loginfo("Görev başlatılıyor: Kalkış yapılıyor...")
        self.takeoff_control.takeoff()  # Kalkış işlemini başlatır

        rospy.loginfo("Kalkış tamamlandı, çizgi takibi başlıyor...")
        rate = rospy.Rate(10)  # 10 Hz döngü

        while not rospy.is_shutdown():
            # Kameralardan görüntü al
            front_frame = self.front_camera.image
            downward_frame = self.downward_camera.image

            processed_frame = None
            if downward_frame is not None:
                # Aşağıya bakan kameradan gelen görüntüyü işleme
                processed_frame, direction = self.line_follower.follow_line(downward_frame)
                rospy.loginfo(f"Yön: {direction}")

            # Ekranları birleştir
            if front_frame is not None and processed_frame is not None:
                # İki görüntüyü yatay olarak birleştir
                combined_frame = np.hstack((front_frame, processed_frame))
            elif front_frame is not None:
                # Ön kamera görüntüsü var ama işlenmiş yoksa
                combined_frame = front_frame
            elif processed_frame is not None:
                # İşlenmiş görüntü var ama ön kamera yoksa
                combined_frame = processed_frame
            else:
                # Hiç görüntü yoksa boş bir ekran göster
                combined_frame = np.zeros((480, 640 * 2, 3), dtype=np.uint8)

            # Birleştirilmiş görüntüyü göster
            cv2.imshow("Drone Camera View", combined_frame)

            # OpenCV pencere kontrolü
            if cv2.waitKey(1) & 0xFF == ord('q'):
                rospy.loginfo("Görev durduruldu.")
                break

            rate.sleep()

        # Görev tamamlandığında tüm OpenCV pencerelerini kapat
        cv2.destroyAllWindows()

if __name__ == "__main__":
    rospy.init_node('drone_control', anonymous=True)
    
    drone_control = DroneControl()
    try:
        drone_control.start_mission()
    except rospy.ROSInterruptException:
        rospy.loginfo("Görev sonlandırıldı.")

